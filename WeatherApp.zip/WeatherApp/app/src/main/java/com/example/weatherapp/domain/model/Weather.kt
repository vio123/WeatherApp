package com.example.weatherapp.domain.model

data class Weather(
    val temperature:Double
)
