package com.example.weatherapp.domain.repository

import com.example.weatherapp.data.api.WeatherApiService
import com.example.weatherapp.data.model.WeatherResponse
import com.example.weatherapp.domain.model.Weather
import javax.inject.Inject

interface WeatherRepository {
    suspend fun getWeather(latitude: Double, longitude: Double): Weather
}

class DefaultWeatherRepository @Inject constructor(private val weatherApiService: WeatherApiService) :
    WeatherRepository {
    override suspend fun getWeather(latitude: Double, longitude: Double): Weather {
        val weatherResponse = weatherApiService.getWeather(latitude, longitude)
        return weatherResponse.toWeather()
    }
    fun WeatherResponse.toWeather():Weather{
        return Weather(
            temperature = this.currentWeather.temperature
        )
    }
}