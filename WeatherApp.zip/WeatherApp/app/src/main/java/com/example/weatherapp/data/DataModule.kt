package com.example.weatherapp.data

import com.example.weatherapp.data.api.RetrofitClient
import com.example.weatherapp.data.api.WeatherApiService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent


@Module
@InstallIn(SingletonComponent::class)
object DataModule {
    @Provides
    fun provideWeatherApiService(): WeatherApiService {
        return RetrofitClient.createApiService()
    }
}
