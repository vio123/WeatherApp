package com.example.weatherapp.data.model

import com.squareup.moshi.Json

data class Weather(
    @Json(name = "temperature")
    val temperature:Double
)
