package com.example.weatherapp.domain

import com.example.weatherapp.data.api.WeatherApiService
import com.example.weatherapp.domain.repository.DefaultWeatherRepository
import com.example.weatherapp.domain.repository.WeatherRepository
import com.example.weatherapp.domain.usecase.GetWeatherUseCase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
object DomainModule {
    @Provides
    fun provideWeatherRepository(weatherApiService: WeatherApiService): WeatherRepository {
        return DefaultWeatherRepository(weatherApiService)
    }
}

