package com.example.weatherapp.data.model

import com.squareup.moshi.Json

data class WeatherResponse(
    @Json(name = "current_weather")
    val currentWeather:Weather
)
